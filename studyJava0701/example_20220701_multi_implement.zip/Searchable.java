package example_20220701_multi_implement;

public interface Searchable {
	void search(String url);
}
