package slimeLand;

public class buildMonster {

    protected static void buildMonster(){
        slime slimes = new slime();


        switch(){
            case 1:
                slimes.slime();
            break;
        }
    }
    
}
