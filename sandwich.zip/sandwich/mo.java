package sandwich;

import java.util.ArrayList;

public class mo {
    blueberrysand blueberrysand = new blueberrysand("빵", "버터", "블루베리", "아보카도", "egg");
    baconsand baconsand = new baconsand("빵", "버터", "베이컨", "상추");
    abocadosand abocadosand = new abocadosand("빵", "버터", "아보카도","에그");
    eggsalsand eggsalsand = new eggsalsand("빵","버터" , "에그", "샐러드");
    pumkinsand pumkinsand = new pumkinsand("빵", "버터", "호박");
    

   
   

 
}
