package sandwich;

public class sandwich {
    String bread;
    String butter;
}
