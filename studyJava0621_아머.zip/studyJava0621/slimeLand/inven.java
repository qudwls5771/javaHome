package slimeLand;

public class inven {
    
    
}



// 복사 지정  
//      int[] a = { 1, 2, 3, 4 };
//      int[] b = new int[a.length];
//      System.arraycopy(a, 0, b, 0, a.length);
    
